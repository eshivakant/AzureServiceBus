﻿namespace Ruvca.ServiceBus
{
    public class Settings
    {
        public static string ConnectionString = "Endpoint=sb://shivademo.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=DJE9lFZLtLPOBdhQYoZkRhBV82tdG1qaNfVrmIWmrvc=";
        public static int RequestResponseTimeout = 30;
    }
}
