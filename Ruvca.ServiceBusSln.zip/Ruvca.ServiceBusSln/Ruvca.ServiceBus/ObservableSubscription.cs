using System;
using Microsoft.ServiceBus.Messaging;

namespace Ruvca.ServiceBus
{
    public class ObservableSubscription<T> : IObservable<T> where T : new()
    {
        private IObserver<T> _observer;
        private readonly DisposableCient _disposableCient;

        public ObservableSubscription(SubscriptionClient subscriptionClient, Bus bus)
        {
            _disposableCient = new DisposableCient(subscriptionClient);

            _disposableCient.SubscriptionClient?.OnMessage(m =>
            {
                var obj = bus.DeserializeKnownType<T>(m);
                _observer.OnNext(obj);
            });
        }

        public void Dispose()
        {
            _disposableCient.Dispose();
        }

        public IDisposable Subscribe(IObserver<T> observer)
        {
            this._observer = observer;
            return _disposableCient;
        }

        class DisposableCient:IDisposable
        {
            public readonly SubscriptionClient SubscriptionClient;

            public DisposableCient(SubscriptionClient subscriptionClient)
            {
                SubscriptionClient = subscriptionClient;
            }

            public void Dispose()
            {
                SubscriptionClient.Close();
            }
           
        }
    }
}