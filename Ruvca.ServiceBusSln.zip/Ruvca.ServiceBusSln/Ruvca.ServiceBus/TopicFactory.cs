using System;
using System.Diagnostics;
using Microsoft.ServiceBus;
using Microsoft.ServiceBus.Messaging;

namespace Ruvca.ServiceBus
{
    internal class TopicFactory
    {
        static NamespaceManager _manager = NamespaceManager.CreateFromConnectionString(Settings.ConnectionString);


        /// <summary>
        /// Queue that will autodelete itself after 1 min idle time
        /// </summary>
        /// <param name="topicName"></param>
        /// <returns>QueueClient</returns>
        public static void CreateTemporaryQueue(string topicName)
        {
            var desc = new TopicDescription(topicName) {AutoDeleteOnIdle = TimeSpan.FromMinutes(1)};
            CreateTopic(desc);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="topicName"></param>
        public static void CreateTopic(string topicName)
        {
            if (!_manager.TopicExists(topicName))
            {
                Debug.Write("Creating Topic: " + topicName + "...");
                _manager.CreateTopic(topicName);
                Debug.Write("Created Topic: " + topicName + "...");
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="desc"></param>
        public static void CreateTopic(TopicDescription desc)
        {
            var manager = NamespaceManager.CreateFromConnectionString(Settings.ConnectionString);
            if (!manager.TopicExists(desc.Path))
            {
                Debug.Write("Creating topic: " + desc.Path + "...");
                manager.CreateTopic(desc.Path);
                Debug.Write("Created topic: " + desc.Path + "...");

            }
        }

        public static void CreateSubscription(string topic, string subscriptionPath)
        {
            var manager = NamespaceManager.CreateFromConnectionString(Settings.ConnectionString);
            if (!manager.SubscriptionExists(topic, subscriptionPath))
            {
                Debug.Write("Creating subscription: " + subscriptionPath + "...");
                var desc = new SubscriptionDescription(topic, subscriptionPath)
                {
                    AutoDeleteOnIdle = TimeSpan.FromMinutes(10)
                };
                manager.CreateSubscription(desc);
                Debug.Write("Created subscription: " + subscriptionPath + "...");

            }
        }
    }
}