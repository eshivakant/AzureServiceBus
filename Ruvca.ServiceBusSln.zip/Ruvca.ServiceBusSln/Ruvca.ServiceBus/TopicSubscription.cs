using System;
using System.Runtime.Serialization;
using Microsoft.ServiceBus.Messaging;

namespace Ruvca.ServiceBus
{
    public class TopicSubscription<T> : IDisposable where T : new()
    {
        private readonly SubscriptionClient _subscriptionClient;
        public int Concurrency { get; set; }

        public TopicSubscription(SubscriptionClient subscriptionClient, Action<T> handler, Bus bus)
        {
            _subscriptionClient = subscriptionClient;


            var options = new OnMessageOptions()
            {
                AutoComplete = false,
                MaxConcurrentCalls = Math.Max(1, Concurrency)
            };


            _subscriptionClient.OnMessage(m =>
            {
                var obj = bus.DeserializeKnownType<T>(m);
                handler.Invoke(obj);
            }, options);
        }

        public void Dispose()
        {
            _subscriptionClient.Close();
        }
    }


    public class QueueSubscription<T> : IDisposable where T : new()
    {
        private readonly QueueClient _queueClient;

        public QueueSubscription(QueueClient queueClient, Action<T> handler, Bus bus)
        {
            _queueClient = queueClient;

            var options = new OnMessageOptions()
            {
                AutoComplete = false,
                MaxConcurrentCalls = Math.Max(1, Concurrency)
            };

        _queueClient.OnMessage(m =>
            {
                try
                {
                    var obj = bus.DeserializeKnownType<T>(m);
                    if (obj == null) throw new SerializationException();
                    handler.Invoke(obj);

                    m.Complete();
                }
                catch (SerializationException ex)
                {
                    m.DeadLetter("Error deserializing message", $"message does not appear to be of valid content type {bus.ContentType}");
                }
                catch (Exception)
                {
                    m.Abandon();
                }
            }, options);
        }

        public ReceiveMode? ReceiveMode { get; set; }
        public int Concurrency { get; set; }

        public void Dispose()
        {
            _queueClient.Close();
        }
    }

}