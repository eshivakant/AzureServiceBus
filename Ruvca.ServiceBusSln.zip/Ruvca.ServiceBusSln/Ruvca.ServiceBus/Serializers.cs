﻿using System;
using System.IO;
using System.Text;
using System.Xml.Serialization;
using Newtonsoft.Json;

namespace Ruvca.ServiceBus
{
    public static class Serializers
    {
        public static string ToJson<T>(this T value)
        {
            var sb = new StringBuilder();
            var sw = new StringWriter(sb);
            var jsonWriter = new JsonTextWriter(sw);
            JsonSerializer jsonSerializer = new JsonSerializer
            {
                DefaultValueHandling = DefaultValueHandling.Ignore,
                NullValueHandling = NullValueHandling.Ignore
            };
            jsonSerializer.Serialize(jsonWriter, value);
            return sb.ToString();
        }

        public static string ToXml<T>(this T value)
        {
            var serializer = new XmlSerializer(typeof(T));


            using (StringWriter textWriter = new StringWriter())
            {
                serializer.Serialize(textWriter, value);
                return textWriter.ToString();
            }
        }

        public static T DeserializeJson<T>(this string json) where T : new()
        {
            if (string.IsNullOrWhiteSpace(json) || !json.Trim().StartsWith("{")) return new T();

            try
            {
                return JsonConvert.DeserializeObject<T>(json);
            }
            catch
            {
                return default(T);
            }
        }

        public static object DeserializeJson(this string json, Type type)
        {
            if (string.IsNullOrWhiteSpace(json) || !json.Trim().StartsWith("{")) return null;

            try
            {
                return JsonConvert.DeserializeObject(json, type);
            }
            catch
            {
                return null;
            }
        }

        public static T DeserializeFromXml<T>(this string xml) where T : new()
        {
            if (string.IsNullOrWhiteSpace(xml))
                return new T();

            T value = default(T);
            try
            {
                var serializer = new XmlSerializer(typeof(T));
                using (var reader = new StringReader(xml))
                {
                    value = (T)serializer.Deserialize(reader);
                }
            }
            catch (Exception)
            {
                return new T();
            }
            return value;
        }

    }
}


