using System;
using System.Diagnostics;
using Microsoft.ServiceBus;
using Microsoft.ServiceBus.Messaging;


namespace Ruvca.ServiceBus
{
    public static class QueueFactory
    {
        static NamespaceManager _manager = NamespaceManager.CreateFromConnectionString(Settings.ConnectionString);


        /// <summary>
        /// Queue that will autodelete itself after 1 min idle time
        /// </summary>
        /// <param name="queueName"></param>
        /// <returns>QueueClient</returns>
        public static void CreateTemporaryQueue(string queueName)
        {
            var desc = new QueueDescription(queueName) {AutoDeleteOnIdle = TimeSpan.FromMinutes(1)};
            CreateQueue(desc);
        }

        /// <summary>
        /// will create queue if it doesn't exist
        /// </summary>
        /// <param name="queueName"></param>
        public static void CreateQueue(string queueName)
        {
            if (!_manager.QueueExists(queueName))
            {
                Debug.Write("Creating queue: " + queueName + "...");
                _manager.CreateQueue(queueName);
                Debug.Write("Created queue: " + queueName + "...");
            }
        }

        /// <summary>
        /// /// will create queue if it doesn't exist
        /// </summary>
        /// <param name="desc"></param>
        public static void CreateQueue(QueueDescription desc)
        {
            var manager = NamespaceManager.CreateFromConnectionString(Settings.ConnectionString);
            if (!manager.QueueExists(desc.Path))
            {
                Debug.Write("Creating queue: " + desc.Path + "...");
                manager.CreateQueue(desc);
                Debug.Write("Created queue: " + desc.Path + "...");
            }
        }

    }
}