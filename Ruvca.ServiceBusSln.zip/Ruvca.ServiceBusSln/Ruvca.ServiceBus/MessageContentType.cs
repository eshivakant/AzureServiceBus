namespace Ruvca.ServiceBus
{
    public enum MessageContentType
    {
        Binary,
        Json,
        Xml,
        String
    }
}