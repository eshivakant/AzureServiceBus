﻿using System;
using System.Threading;
using System.Threading.Tasks;
using Ruvca.ServiceBus;
using Ruvca.Contracts;

namespace SenderConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            //SendSubscribeToQueue();
            //SendSubscribeToQueueContrainedConcurrency();
            //PublishSubscribeTest();
            //PublishSubscribeTestWithObservables();
            Console.ReadLine();
        }


        private static void SendSubscribeToQueue()
        {
            Task.Run(() => SendToQueue());
            Task.Run(() =>
            {
                SubscribeToQueue();
            });
        }


        private static void SendSubscribeToQueueContrainedConcurrency()
        {
            Task.Run(() => SendToQueue());
            Task.Run(() =>
            {
                Thread.Sleep(4000);
                SubscribeToQueue(5);
            });
        }

        public static void SubscribeToQueue(int? concurreny=null)
        {
            string queuepath = "TestQ";

            var bus = new Bus(MessageContentType.Json);

            if(concurreny.HasValue)
                bus.SubscribeToQueue<Trade>(queuepath, (m) => Console.WriteLine("Received " + m.Id), concurreny.Value);
            else
                bus.SubscribeToQueue<Trade>(queuepath, (m) => Console.WriteLine("Received " + m.Id));

            Console.ReadLine();
        }



        public static void SendToQueue()
        {
            string queuepath = "TestQ";

            var bus = new Bus(MessageContentType.Json);

            for (int i = 0; i < 10; i++)
            {
                var testTrade = new Trade(i, "HSBC", "GBPEUR", "NEW", "buy", 1123.33M, 100, 1123.33M);
                Console.WriteLine("sent:"+ testTrade.Id);
                bus.SendToQueue(testTrade, queuepath);
            }

            Console.ReadLine();
        }


        private static void PublishSubscribeTestWithObservables()
        {
            Task.Run(() => PublishToTopic());
            Task.Run(() =>
            {
                SusbcribeToTopicUsingObservables();
            });
        }

       

        private static void PublishSubscribeTest()
        {

            Task.Run(() => PublishToTopic());
            Task.Run(() =>
            {
                SusbcribeToTopic();
            });
        }

        private static void SusbcribeToTopic()
        {
            string topic = "TestTopic";

            var bus = new Bus(MessageContentType.Json);

            var disp = bus.SubscribeToTopic<Trade>(topic, msg => Console.WriteLine("Received:" + msg.Id));

            Console.ReadLine();

            disp.Dispose();
        }

        private static void SusbcribeToTopicUsingObservables()
        {
            string topic = "TestTopic";

            var bus = new Bus(MessageContentType.Json);

            var observableSubscription = bus.SubscribeToTopic<Trade>(topic);

            observableSubscription.Subscribe(new TradeDataProvider()); //or use rx

            Console.ReadLine();
            
            observableSubscription.Dispose();
        }


        public static void PublishToTopic()
        {
            string topic = "TestTopic";

            var bus = new Bus(MessageContentType.Json);

            int count = 0;
            while (true)
            {
                var testTrade = new Trade(count++, "HSBC", "GBPEUR", "NEW", "buy", 1123.33M, 100, 1123.33M);

                bus.PublichToTopic(testTrade, topic);

                Console.WriteLine("published: " + testTrade.Id);

                Thread.Sleep(100);
            }

        }


    }


    public class TradeDataProvider : IObserver<Trade>
    {
        public void OnNext(Trade value)
        {
            Console.WriteLine("Received:" + value.Id);
        }

        public void OnError(Exception error)
        {
            Console.WriteLine("Error:"+ error.ToString());
        }

        public void OnCompleted()
        {
            Console.WriteLine("Finished");
        }
    }


    
}
