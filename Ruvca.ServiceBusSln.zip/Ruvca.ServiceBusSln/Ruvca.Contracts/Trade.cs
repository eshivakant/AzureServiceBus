﻿using System;

namespace Ruvca.Contracts
{
    public class Trade
    {
        public long Id { get; set; }
        public string CurrencyPair { get; set; }
        public string Customer { get; set; }
        public decimal TradePrice { get; set; }
        public decimal MarketPrice { get; set; }
        public decimal PercentFromMarket { get; set; }
        public decimal Amount { get; set; }
        public string BuyOrSell { get; set; }
        public string Status { get; set; }
        public DateTime Timestamp { get; set; }

        public Trade()
        {
            
        }

        public Trade(long id, string customer, string currencyPair, string status, string buyOrSell, decimal tradePrice,
            decimal amount, decimal marketPrice = 0, DateTime? timeStamp = null)
        {
            Id = id;
            Customer = customer;
            CurrencyPair = currencyPair;
            Status = status;
            MarketPrice = marketPrice;
            TradePrice = tradePrice;
            Amount = amount;
            BuyOrSell = buyOrSell;
            Timestamp = timeStamp.HasValue ? timeStamp.Value : DateTime.Now;
        }
    }
}
